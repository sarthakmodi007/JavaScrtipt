class Fetchcall {

   async Fetch() {
    let store = [];
    try {
      await fetch("https://jsonplaceholder.typicode.com/photos")
        .then((response) => response.json())
        .then((data) => store.push(data));

      var d = store[0];

      d.slice(0, 500).map(function (g) {
        let image = document.createElement("img");
        image.src = g.thumbnailUrl;
        let oop = document.querySelector(".cell-container").appendChild(image);
        console.log("check--", oop);
        return oop;
        
      });
    } catch (err) {
      alert("please check your internet");
    }
  }
}
const xyz = new Fetchcall();
document.getElementById("lbc").innerHTML = xyz.Fetch();
