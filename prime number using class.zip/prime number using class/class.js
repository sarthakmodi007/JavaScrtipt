class primeNumber {
  constructor(number) {
    this.name = number;
  }
  prime() {
    let i,j,
      arr = [];
    for (i = this.name; i <= 100; i++) {
      let IsPrime = 1;
      for (j = 2; j <= i / 2; j++) {
        if (i % j == 0) {
          IsPrime = 0;
          break;
        }
      }
        if (IsPrime == 1) {
        arr.push(i);
      }
    }
    return arr;
  }

  getStructure() {

    let getprimenumbers = this.prime();

    let cell = '<div class="cell-container" id="lbc">';
    getprimenumbers.forEach(function (G) {
      cell += '<div class="cell">' + G + "</div>";
    });
    cell += "</div>";

    let test = cell;
    this.getColor();

    return test;
  }
  getColor() {
    const getClick = this.prime();
    getClick.forEach(function (abcd) {
      onclick = function (abcd) {
        abcd.target.style.backgroundColor = "red";
        abcd.target.style.color = "white";
      };
    });
  }
}
let myNumber = new primeNumber(2);
document.getElementById("abc").innerHTML = myNumber.getStructure();


 
